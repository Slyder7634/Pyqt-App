#!/usr/bin/env python3
"""
NextUp Robot Control — PyQt5 shell (Point Planning page).

Visual-only first pass. No ROS yet: every control is wired to a stub so the
layout can be checked on the real panel before the rclpy jog core lands.

Run:  python3 main.py
"""

import os
import sys

from PyQt5 import QtCore, QtWidgets, uic

HERE = os.path.dirname(os.path.abspath(__file__))
UI_FILE = os.path.join(HERE, "main_window.ui")
QSS_FILE = os.path.join(HERE, "style.qss")

JOINT_AXES = ["J1", "J2", "J3", "J4", "J5", "J6"]
CART_AXES = ["X", "Y", "Z", "R", "P", "W"]

# Placeholder frames; the real list comes from TF once ROS is connected.
FRAMES = ["base_link", "tool0", "flange", "world"]

# Placeholder points so the list has something to lay out against.
DEMO_POINTS = ["home", "startP", "topStart", "topEnd", "midPoint",
               "botStart", "botEnd", "botExt", "c1", "c2", "c3", "c4", "c5"]


def restyle(widget):
    """Re-apply QSS after a dynamic property changes.

    Qt does not repaint on property change by itself, so any code that sets
    a `state` property must call this or the LED will not visibly update.
    """
    widget.style().unpolish(widget)
    widget.style().polish(widget)


class PointRow(QtWidgets.QWidget):
    """One row of the point list: index badge, name, and three touch actions."""

    def __init__(self, index, name, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(8)

        badge = QtWidgets.QLabel(str(index))
        badge.setAlignment(QtCore.Qt.AlignCenter)
        badge.setFixedSize(34, 34)
        badge.setStyleSheet(
            "background:#eff6ff; color:#2563eb; border-radius:17px;"
            "font-weight:700; font-size:13px;"
        )
        layout.addWidget(badge)

        label = QtWidgets.QLabel(name)
        label.setStyleSheet(
            "background:#eff6ff; color:#2563eb; border-radius:8px;"
            "padding:7px 14px; font-weight:600;"
        )
        layout.addWidget(label)
        layout.addStretch(1)

        # 44px minimum touch target, per the sizing rule in style.qss.
        for text, colour in (("\u27a4", "#22c55e"),
                             ("\u270e", "#f59e0b"),
                             ("\u2716", "#ef4444")):
            btn = QtWidgets.QPushButton(text)
            btn.setFixedSize(44, 44)
            btn.setCursor(QtCore.Qt.PointingHandCursor)
            btn.setStyleSheet(
                f"background:{colour}; color:#ffffff; border:none;"
                "border-radius:10px; font-size:16px;"
            )
            layout.addWidget(btn)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi(UI_FILE, self)

        self._setup_nav()
        self._setup_leds()
        self._setup_points()
        self._setup_frames()
        self._setup_jog()
        self._setup_clock()

        # Column widths: editor 3 / list 3 / control 5, matching the web layout.
        self.bodyLayout.setStretch(0, 3)
        self.bodyLayout.setStretch(1, 3)
        self.bodyLayout.setStretch(2, 5)

    # ── navigation ───────────────────────────────────────────────────────
    def _setup_nav(self):
        self.nav_buttons = [
            self.navPointPlanning, self.navPathPlanning, self.navIoControl,
            self.navMainTree, self.navClientControl, self.navErrorHandling,
        ]
        group = QtWidgets.QButtonGroup(self)
        group.setExclusive(True)
        for btn in self.nav_buttons:
            group.addButton(btn)

    # ── status LEDs ──────────────────────────────────────────────────────
    def _setup_leds(self):
        self.leds = {}
        for prefix in ("op", "fault", "homing", "emergency"):
            self.leds[prefix] = [
                getattr(self, f"{prefix}Led{i}") for i in range(1, 7)
            ]
        # Demo state so the panel is not a wall of grey during layout review.
        self.set_led_row("op", [True] * 6)
        self.set_led_row("homing", [True, True, True, False, False, False])

    def set_led_row(self, prefix, states, on_state="on"):
        """states: list of 6 bools. Called from ROS callbacks later."""
        for led, active in zip(self.leds[prefix], states):
            led.setProperty("state", on_state if active else "")
            restyle(led)

    # ── point list ───────────────────────────────────────────────────────
    def _setup_points(self):
        self.pointList.setSelectionMode(
            QtWidgets.QAbstractItemView.SingleSelection)
        for i, name in enumerate(DEMO_POINTS, start=1):
            item = QtWidgets.QListWidgetItem(self.pointList)
            row = PointRow(i, name)
            # Explicit height: sizeHint() is computed before the stylesheet
            # is applied, so it under-measures and clips the 44px buttons.
            item.setSizeHint(QtCore.QSize(0, 62))
            self.pointList.addItem(item)
            self.pointList.setItemWidget(item, row)
        self.pointCountLabel.setText(f"{len(DEMO_POINTS)} points")

    # ── frames ───────────────────────────────────────────────────────────
    def _setup_frames(self):
        self.servoFrameSelect.addItems(FRAMES)
        self.tfFrameSelect.addItems([f"{p}-tf" for p in DEMO_POINTS])
        self.servoFrameSelect.currentTextChanged.connect(
            lambda f: self.activeFrameBadge.setText(f"ACTIVE  {f}"))

    # ── jog ──────────────────────────────────────────────────────────────
    def _setup_jog(self):
        """Collect the jog buttons.

        Deliberately press-and-hold (pressed/released), not clicked: jogging
        is a hold-to-move action. The handlers are stubs — the real ones will
        set a setpoint that a fixed-rate rclpy timer consumes, never publish
        from the GUI thread directly.
        """
        self.jog_buttons = {}
        for prefix, axes in (("joint", JOINT_AXES), ("cart", CART_AXES)):
            for i, axis in enumerate(axes, start=1):
                plus = getattr(self, f"{prefix}Plus{i}")
                minus = getattr(self, f"{prefix}Minus{i}")
                for btn, sign in ((plus, +1), (minus, -1)):
                    btn.pressed.connect(
                        lambda p=prefix, a=i - 1, s=sign: self.jog_start(p, a, s))
                    btn.released.connect(
                        lambda p=prefix, a=i - 1: self.jog_stop(p, a))
                self.jog_buttons[(prefix, i)] = (plus, minus)

    def jog_start(self, mode, axis_index, sign):
        self.statusbar.showMessage(
            f"jog start — {mode} axis {axis_index} sign {sign:+d}", 2000)

    def jog_stop(self, mode, axis_index):
        self.statusbar.showMessage(
            f"jog stop — {mode} axis {axis_index}", 1000)

    # ── clock ────────────────────────────────────────────────────────────
    def _setup_clock(self):
        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self._tick()

    def _tick(self):
        now = QtCore.QTime.currentTime().toString("HH:mm:ss")
        try:
            load = os.getloadavg()
            load_text = f"{load[0]:.2f} {load[1]:.2f} {load[2]:.2f}"
        except OSError:
            load_text = "-- -- --"
        self.systemStatusLabel.setText(
            f"TIME : {now}\nUpTime: --\nLoad: {load_text}")


def main():
    QtWidgets.QApplication.setAttribute(
        QtCore.Qt.AA_EnableHighDpiScaling, True)
    app = QtWidgets.QApplication(sys.argv)

    with open(QSS_FILE, "r") as fh:
        app.setStyleSheet(fh.read())

    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
