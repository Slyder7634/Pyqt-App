#!/usr/bin/env python3
"""
NextUp Robot Control — PyQt5 Point Planning page.

Point data is loaded from:
    /home/nextup/NextupRobot/src/active_project_configs/planning_data/points.yaml

The UI no longer uses DEMO_POINTS.  The YAML file is the source of truth for
the point list and point editor.
"""

import os
import sys
import subprocess
from copy import deepcopy
from datetime import datetime

import yaml
from PyQt5 import QtCore, QtWidgets, uic


HERE = os.path.dirname(os.path.abspath(__file__))
UI_FILE = os.path.join(HERE, "main_window.ui")
QSS_FILE = os.path.join(HERE, "style.qss")

POINTS_FILE = "/home/nextup/NextupRobot/src/active_project_configs/planning_data/points.yaml"

JOINT_AXES = ["J1", "J2", "J3", "J4", "J5", "J6"]
CART_AXES = ["X", "Y", "Z", "R", "P", "W"]

# Placeholder frames; replace with TF frames when ROS is connected.
FRAMES = ["base_link", "tool0", "flange", "world"]


def restyle(widget):
    """Re-apply QSS after a dynamic property changes."""
    widget.style().unpolish(widget)
    widget.style().polish(widget)


class PointRow(QtWidgets.QWidget):
    """
    One row of the point list.

    Signals:
        execute(point_index)
        edit(point_index)
        delete(point_index)
    """

    executeRequested = QtCore.pyqtSignal(int)
    editRequested = QtCore.pyqtSignal(int)
    deleteRequested = QtCore.pyqtSignal(int)

    def __init__(self, index, name, parent=None):
        super().__init__(parent)
        self.point_index = index

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(8)

        badge = QtWidgets.QLabel(str(index + 1))
        badge.setAlignment(QtCore.Qt.AlignCenter)
        badge.setFixedSize(34, 34)
        badge.setStyleSheet(
            "background:#eff6ff; color:#2563eb; border-radius:17px;"
            "font-weight:700; font-size:13px;"
        )
        layout.addWidget(badge)

        label = QtWidgets.QLabel(name)
        label.setStyleSheet(
            "background:#eff6ff; color:#2563eb; border-radius:8px;"
            "padding:7px 14px; font-weight:600;"
        )
        layout.addWidget(label)
        layout.addStretch(1)

        for text, colour, signal in (
            ("\u27a4", "#22c55e", self.executeRequested),
            ("\u270e", "#f59e0b", self.editRequested),
            ("\u2716", "#ef4444", self.deleteRequested),
        ):
            btn = QtWidgets.QPushButton(text)
            btn.setFixedSize(44, 44)
            btn.setCursor(QtCore.Qt.PointingHandCursor)
            btn.setStyleSheet(
                f"background:{colour}; color:#ffffff; border:none;"
                "border-radius:10px; font-size:16px;"
            )
            btn.clicked.connect(lambda checked=False, s=signal:
                                s.emit(self.point_index))
            layout.addWidget(btn)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi(UI_FILE, self)

        self.points = []
        self.points_file_name = ""
        self.selected_point_index = None

        self._setup_nav()
        self._setup_leds()
        self._setup_frames()
        self._setup_jog()
        self._setup_clock()
        self._setup_point_functionality()

        # Column widths: editor 3 / list 3 / control 5.
        self.bodyLayout.setStretch(0, 3)
        self.bodyLayout.setStretch(1, 3)
        self.bodyLayout.setStretch(2, 5)

    # ── point YAML storage ────────────────────────────────────────────────

    def _setup_point_functionality(self):
        """Connect all point-management controls and load points from YAML."""

        self.pointList.setSelectionMode(
            QtWidgets.QAbstractItemView.SingleSelection
        )

        self.pointList.itemSelectionChanged.connect(self._on_list_selection)

        self.addPointButton.clicked.connect(self.add_point)
        self.updatePointButton.clicked.connect(self.update_point)

        self.reloadPointsButton.clicked.connect(self.load_points)
        self.viewYamlButton.clicked.connect(self.view_yaml)

        self.deleteAllButton.clicked.connect(self.delete_all_points)
        self.undoButton.clicked.connect(self.clear_editor)

        self.pointList.itemDoubleClicked.connect(
            lambda item: self._edit_list_item(item)
        )

        self.load_points()

    def _read_points_file(self):
        """Read and validate the points.yaml structure."""

        if not os.path.isfile(POINTS_FILE):
            raise FileNotFoundError(
                f"Points file does not exist:\n{POINTS_FILE}"
            )

        with open(POINTS_FILE, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        if not isinstance(data, dict):
            raise ValueError("points.yaml root must be a YAML mapping.")

        points = data.get("points", [])
        if points is None:
            points = []

        if not isinstance(points, list):
            raise ValueError("'points' in points.yaml must be a list.")

        # Keep the complete YAML metadata, including history and any future
        # fields, instead of rebuilding points from only the visible fields.
        self.points_file_name = data.get("points_file_name", "")
        return data, points

    def _write_points_file(self, points):
        """
        Write the complete YAML document while preserving the top-level
        points_file_name and all point fields that the application does not edit.
        """

        data, _ = self._read_points_file()
        data["points"] = points

        directory = os.path.dirname(POINTS_FILE)
        os.makedirs(directory, exist_ok=True)

        # Atomic replacement prevents a partially-written YAML file if the
        # application is interrupted during a save.
        temp_file = POINTS_FILE + ".tmp"

        with open(temp_file, "w", encoding="utf-8") as fh:
            yaml.safe_dump(
                data,
                fh,
                sort_keys=False,
                allow_unicode=True,
                default_flow_style=False,
            )

        os.replace(temp_file, POINTS_FILE)

    def load_points(self):
        """Fetch the current point list from points.yaml."""

        try:
            data, points = self._read_points_file()
            self.points = deepcopy(points)
            self.points_file_name = data.get("points_file_name", "")
            self._refresh_point_list()

            self.statusbar.showMessage(
                f"Loaded {len(self.points)} points from {POINTS_FILE}", 3000
            )

        except Exception as exc:
            self.points = []
            self._refresh_point_list()
            QtWidgets.QMessageBox.critical(
                self,
                "Unable to load points",
                f"Could not read points.yaml.\n\n{exc}",
            )

    def _refresh_point_list(self):
        """Rebuild the visible list from self.points."""

        self.pointList.blockSignals(True)
        self.pointList.clear()

        for index, point in enumerate(self.points):
            name = str(point.get("name", f"point-{index + 1}"))
            item = QtWidgets.QListWidgetItem()
            row = PointRow(index, name)

            item.setSizeHint(QtCore.QSize(0, 62))

            row.executeRequested.connect(self.execute_point)
            row.editRequested.connect(self.edit_point)
            row.deleteRequested.connect(self.delete_point)

            self.pointList.addItem(item)
            self.pointList.setItemWidget(item, row)

        self.pointList.blockSignals(False)

        self.pointCountLabel.setText(f"{len(self.points)} points")

        if self.selected_point_index is not None:
            if 0 <= self.selected_point_index < len(self.points):
                self.pointList.setCurrentRow(self.selected_point_index)
            else:
                self.selected_point_index = None

    def _on_list_selection(self):
        row = self.pointList.currentRow()

        if 0 <= row < len(self.points):
            self.selected_point_index = row
            self._populate_editor(self.points[row])

    def _edit_list_item(self, item):
        row = self.pointList.row(item)
        if 0 <= row < len(self.points):
            self.edit_point(row)

    # ── editor ─────────────────────────────────────────────────────────────

    def _populate_editor(self, point):
        """Populate the Point Editor from a YAML point."""

        self.pointNameInput.setText(str(point.get("name", "")))
        self.sequenceInput.setValue(int(point.get("sequence", 1) or 1))

        self.enableTfCheck.setChecked(bool(point.get("is_tf", False)))
        self.editableCheck.setChecked(bool(point.get("is_editable", True)))

        nature = point.get("nature", "")
        self.natureInput.setPlainText("" if nature is None else str(nature))

        date_time = point.get("date_time", "")
        self.dateTimeInput.setText("" if date_time is None else str(date_time))

    def clear_editor(self):
        """Clear the editor and deselect the current point."""

        self.selected_point_index = None
        self.pointList.clearSelection()

        self.pointNameInput.clear()
        self.sequenceInput.setValue(1)
        self.enableTfCheck.setChecked(False)
        self.editableCheck.setChecked(True)
        self.natureInput.clear()
        self.dateTimeInput.clear()

        self.statusbar.showMessage("Point editor cleared", 1500)

    def _editor_values(self):
        name = self.pointNameInput.text().strip()
        nature = self.natureInput.toPlainText().strip()

        if not name:
            raise ValueError("Point name cannot be empty.")

        if any(
            str(point.get("name", "")).strip() == name
            and i != self.selected_point_index
            for i, point in enumerate(self.points)
        ):
            raise ValueError(f"A point named '{name}' already exists.")

        return {
            "name": name,
            "sequence": self.sequenceInput.value(),
            "is_tf": self.enableTfCheck.isChecked(),
            "is_editable": self.editableCheck.isChecked(),
            "nature": nature,
        }

    def add_point(self):
        """Add a new point to the YAML file."""

        try:
            values = self._editor_values()
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, "Invalid point", str(exc))
            return

        point = {
            "name": values["name"],
            "date_time": datetime.now().strftime("%d%b_%H%M").lower(),
            "sequence": values["sequence"],
            "nature": values["nature"],
            "is_tf": values["is_tf"],
            "is_calibrated": False,
            "is_editable": values["is_editable"],
            "joints_values": {},
            "coordinate": {},
        }

        try:
            self.points.append(point)
            self._write_points_file(self.points)

            new_index = len(self.points) - 1
            self.selected_point_index = new_index
            self._refresh_point_list()
            self.pointList.setCurrentRow(new_index)

            self.statusbar.showMessage(
                f"Added point '{point['name']}'", 2500
            )

        except Exception as exc:
            # Re-read from disk so the in-memory state cannot drift from YAML.
            self.load_points()
            QtWidgets.QMessageBox.critical(
                self, "Save failed", f"Could not save the new point.\n\n{exc}"
            )

    def update_point(self):
        """Update the editable metadata of the selected YAML point."""

        index = self.selected_point_index
        if index is None or not (0 <= index < len(self.points)):
            QtWidgets.QMessageBox.information(
                self, "No point selected", "Select a point to update."
            )
            return

        original = self.points[index]

        if original.get("is_editable", True) is False:
            QtWidgets.QMessageBox.warning(
                self,
                "Point locked",
                f"'{original.get('name', 'point')}' is marked as not editable.",
            )
            return

        try:
            values = self._editor_values()
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, "Invalid point", str(exc))
            return

        # Preserve all YAML fields such as joints_values, coordinate and
        # history. Only fields represented by this editor are changed.
        updated = deepcopy(original)
        updated["name"] = values["name"]
        updated["sequence"] = values["sequence"]
        updated["nature"] = values["nature"]
        updated["is_tf"] = values["is_tf"]
        updated["is_editable"] = values["is_editable"]

        # Keep the existing date_time because it describes the point record.
        self.points[index] = updated

        try:
            self._write_points_file(self.points)
            self._refresh_point_list()
            self.pointList.setCurrentRow(index)

            self.statusbar.showMessage(
                f"Updated point '{updated['name']}'", 2500
            )

        except Exception as exc:
            self.load_points()
            QtWidgets.QMessageBox.critical(
                self, "Save failed", f"Could not update the point.\n\n{exc}"
            )

    def edit_point(self, index):
        """Load a point into the editor."""

        if not (0 <= index < len(self.points)):
            return

        self.selected_point_index = index
        self.pointList.setCurrentRow(index)
        self._populate_editor(self.points[index])

        self.statusbar.showMessage(
            f"Editing point '{self.points[index].get('name', '')}'", 2000
        )

    def execute_point(self, index):
        """
        Execute/select a point.

        Motion is intentionally not implemented here yet. This is the single
        integration point where the ROS/MoveIt command should be connected.
        """

        if not (0 <= index < len(self.points)):
            return

        point = self.points[index]
        self.selected_point_index = index
        self.pointList.setCurrentRow(index)
        self._populate_editor(point)

        self.statusbar.showMessage(
            f"Selected point '{point.get('name', '')}' for execution",
            2500,
        )

        # Future ROS integration:
        #   self.motion_controller.execute_point(point)

    def delete_point(self, index):
        """Delete one point from YAML after confirmation."""

        if not (0 <= index < len(self.points)):
            return

        point = self.points[index]
        name = str(point.get("name", f"point-{index + 1}"))

        if point.get("is_editable", True) is False:
            QtWidgets.QMessageBox.warning(
                self,
                "Point locked",
                f"'{name}' is marked as not editable.",
            )
            return

        answer = QtWidgets.QMessageBox.question(
            self,
            "Delete point",
            f"Delete point '{name}'?\n\nThis will update points.yaml.",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No,
        )

        if answer != QtWidgets.QMessageBox.Yes:
            return

        removed = self.points.pop(index)

        try:
            self._write_points_file(self.points)
            self.selected_point_index = None
            self._refresh_point_list()
            self.clear_editor()

            self.statusbar.showMessage(
                f"Deleted point '{removed.get('name', name)}'", 2500
            )

        except Exception as exc:
            self.load_points()
            QtWidgets.QMessageBox.critical(
                self, "Delete failed", f"Could not delete the point.\n\n{exc}"
            )

    def delete_all_points(self):
        """Delete all editable points from YAML."""

        if not self.points:
            return

        answer = QtWidgets.QMessageBox.question(
            self,
            "Delete all points",
            "Delete all editable points from points.yaml?\n\n"
            "Non-editable/locked points will be kept.",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No,
        )

        if answer != QtWidgets.QMessageBox.Yes:
            return

        kept = [
            point for point in self.points
            if point.get("is_editable", True) is False
        ]

        deleted_count = len(self.points) - len(kept)
        self.points = kept

        try:
            self._write_points_file(self.points)
            self.selected_point_index = None
            self._refresh_point_list()
            self.clear_editor()

            self.statusbar.showMessage(
                f"Deleted {deleted_count} editable points", 2500
            )

        except Exception as exc:
            self.load_points()
            QtWidgets.QMessageBox.critical(
                self, "Delete failed", f"Could not delete points.\n\n{exc}"
            )

    def view_yaml(self):
        """Open the actual points.yaml file in the desktop text editor."""

        if not os.path.isfile(POINTS_FILE):
            QtWidgets.QMessageBox.warning(
                self,
                "Points YAML not found",
                POINTS_FILE,
            )
            return

        try:
            subprocess.Popen(["xdg-open", POINTS_FILE])
        except Exception as exc:
            QtWidgets.QMessageBox.warning(
                self,
                "Unable to open YAML",
                f"Could not open the file with xdg-open.\n\n{exc}",
            )

    # ── navigation ────────────────────────────────────────────────────────

    def _setup_nav(self):
        self.nav_buttons = [
            self.navPointPlanning,
            self.navPathPlanning,
            self.navIoControl,
            self.navMainTree,
            self.navClientControl,
            self.navErrorHandling,
        ]

        group = QtWidgets.QButtonGroup(self)
        group.setExclusive(True)

        for btn in self.nav_buttons:
            group.addButton(btn)

    # ── status LEDs ───────────────────────────────────────────────────────

    def _setup_leds(self):
        self.leds = {}

        for prefix in ("op", "fault", "homing", "emergency"):
            self.leds[prefix] = [
                getattr(self, f"{prefix}Led{i}") for i in range(1, 7)
            ]

        # Demo state until ROS status callbacks are connected.
        self.set_led_row("op", [True] * 6)
        self.set_led_row("homing", [True, True, True, False, False, False])

    def set_led_row(self, prefix, states, on_state="on"):
        """states: list of 6 bools. Called from ROS callbacks later."""

        for led, active in zip(self.leds[prefix], states):
            led.setProperty("state", on_state if active else "")
            restyle(led)

    # ── frames ────────────────────────────────────────────────────────────

    def _setup_frames(self):
        self.servoFrameSelect.addItems(FRAMES)

        self.servoFrameSelect.currentTextChanged.connect(
            lambda f: self.activeFrameBadge.setText(f"ACTIVE  {f}")
        )

        # TF frame list is now based on loaded points. Reloading the YAML also
        # refreshes this combo box.
        self._refresh_tf_frames()

    def _refresh_tf_frames(self):
        self.tfFrameSelect.clear()
        self.tfFrameSelect.addItems(
            [f"{p.get('name', '')}-tf" for p in self.points]
        )

    # ── jog ────────────────────────────────────────────────────────────────

    def _setup_jog(self):
        """Collect the press-and-hold jog buttons."""

        self.jog_buttons = {}

        for prefix, axes in (
            ("joint", JOINT_AXES),
            ("cart", CART_AXES),
        ):
            for i, axis in enumerate(axes, start=1):
                plus = getattr(self, f"{prefix}Plus{i}")
                minus = getattr(self, f"{prefix}Minus{i}")

                for btn, sign in ((plus, +1), (minus, -1)):
                    btn.pressed.connect(
                        lambda p=prefix, a=i - 1, s=sign:
                        self.jog_start(p, a, s)
                    )
                    btn.released.connect(
                        lambda p=prefix, a=i - 1:
                        self.jog_stop(p, a)
                    )

                self.jog_buttons[(prefix, i)] = (plus, minus)

    def jog_start(self, mode, axis_index, sign):
        self.statusbar.showMessage(
            f"jog start — {mode} axis {axis_index} sign {sign:+d}", 2000
        )

    def jog_stop(self, mode, axis_index):
        self.statusbar.showMessage(
            f"jog stop — {mode} axis {axis_index}", 1000
        )

    # ── clock ──────────────────────────────────────────────────────────────

    def _setup_clock(self):
        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self._tick()

    def _tick(self):
        now = QtCore.QTime.currentTime().toString("HH:mm:ss")

        try:
            load = os.getloadavg()
            load_text = f"{load[0]:.2f} {load[1]:.2f} {load[2]:.2f}"
        except OSError:
            load_text = "-- -- --"

        self.systemStatusLabel.setText(
            f"TIME : {now}\nUpTime: --\nLoad: {load_text}"
        )


def main():
    QtWidgets.QApplication.setAttribute(
        QtCore.Qt.AA_EnableHighDpiScaling, True
    )

    app = QtWidgets.QApplication(sys.argv)

    with open(QSS_FILE, "r", encoding="utf-8") as fh:
        app.setStyleSheet(fh.read())

    window = MainWindow()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
