#!/usr/bin/env python3
"""
NextUp Robot Control — PyQt5 Point Planning page with ROS 2 integration.
STRICT RAW DATA MODE: Shows exact values from topic/YAML with NO unit conversion.
"""

import os
import sys
import subprocess
import math
from copy import deepcopy
from datetime import datetime
import json

import yaml
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from PyQt5 import QtCore, QtWidgets, uic


HERE = os.path.dirname(os.path.abspath(__file__))
UI_FILE = os.path.join(HERE, "main_window.ui")
QSS_FILE = os.path.join(HERE, "style.qss")

POINTS_FILE = "/home/nextup/NextupRobot/src/active_project_configs/planning_data/points.yaml"

JOINT_AXES = ["J1", "J2", "J3", "J4", "J5", "J6"]
CART_AXES = ["X", "Y", "Z", "R", "P", "W"]

FRAMES = ["base_link", "tool0", "flange", "world"]


def restyle(widget):
    """Re-apply QSS after a dynamic property changes."""
    widget.style().unpolish(widget)
    widget.style().polish(widget)


class ROSNode(Node):
    """ROS 2 node for the UI."""
    
    def __init__(self):
        super().__init__('ui_controller')
        self.joint_pub = self.create_publisher(Float64MultiArray, '/ui_commands', 10)
        self.joint_sub = self.create_subscription(
            Float64MultiArray,
            '/joint_values',
            self.joint_callback,
            10
        )
        self.cart_sub = self.create_subscription(
            Float64MultiArray,
            '/cartesian_values',
            self.cart_callback,
            10
        )
        self.joint_data = None
        self.cart_data = None
        
    def joint_callback(self, msg):
        self.joint_data = msg.data
        
    def cart_callback(self, msg):
        self.cart_data = msg.data
        
    def publish_command(self, command_type, axis, value, sign):
        """Publish a UI command."""
        msg = Float64MultiArray()
        msg.data = [float(command_type), float(axis), float(value), float(sign)]
        self.joint_pub.publish(msg)
        self.get_logger().info(f"Published command: {msg.data}")


class PointRow(QtWidgets.QWidget):
    """One row of the point list."""

    executeRequested = QtCore.pyqtSignal(int)
    editRequested = QtCore.pyqtSignal(int)
    deleteRequested = QtCore.pyqtSignal(int)

    def __init__(self, index, name, parent=None):
        super().__init__(parent)
        self.point_index = index

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(8)

        badge = QtWidgets.QLabel(str(index + 1))
        badge.setAlignment(QtCore.Qt.AlignCenter)
        badge.setFixedSize(34, 34)
        badge.setStyleSheet(
            "background:#eff6ff; color:#2563eb; border-radius:17px;"
            "font-weight:700; font-size:13px;"
        )
        layout.addWidget(badge)

        label = QtWidgets.QLabel(name)
        label.setStyleSheet(
            "background:#eff6ff; color:#2563eb; border-radius:8px;"
            "padding:7px 14px; font-weight:600;"
        )
        layout.addWidget(label)
        layout.addStretch(1)

        for text, colour, signal in (
            ("\u27a4", "#22c55e", self.executeRequested),
            ("\u270e", "#f59e0b", self.editRequested),
            ("\u2716", "#ef4444", self.deleteRequested),
        ):
            btn = QtWidgets.QPushButton(text)
            btn.setFixedSize(44, 44)
            btn.setCursor(QtCore.Qt.PointingHandCursor)
            btn.setStyleSheet(
                f"background:{colour}; color:#ffffff; border:none;"
                "border-radius:10px; font-size:16px;"
            )
            btn.clicked.connect(lambda checked=False, s=signal:
                                s.emit(self.point_index))
            layout.addWidget(btn)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node
        uic.loadUi(UI_FILE, self)

        self.points = []
        self.points_file_name = ""
        self.selected_point_index = None
        self.is_loading_point = False

        self._setup_nav()
        self._setup_leds()
        self._setup_frames()
        self._setup_jog()
        self._setup_clock()
        self._setup_point_functionality()
        self._setup_ros_timer()

        self.bodyLayout.setStretch(0, 3)
        self.bodyLayout.setStretch(1, 3)
        self.bodyLayout.setStretch(2, 5)

    def _setup_ros_timer(self):
        """Set up a timer to update UI from ROS data."""
        self._ros_timer = QtCore.QTimer(self)
        self._ros_timer.timeout.connect(self._update_from_ros)
        self._ros_timer.start(50)

    def _update_from_ros(self):
        """Update UI displays from ROS data. STRICT RAW DISPLAY."""
        if self.is_loading_point:
            return

        if self.ros_node.joint_data is not None:
            data = self.ros_node.joint_data
            for i in range(min(6, len(data))):
                # NO MATH. Just display the raw data.
                self._write_display_value("joint", i + 1, data[i])

        if self.ros_node.cart_data is not None:
            data = self.ros_node.cart_data
            for i in range(min(6, len(data))):
                # NO MATH. Just display the raw data.
                self._write_display_value("cart", i + 1, data[i])

    # ── point YAML storage ────────────────────────────────────────────────

    def _setup_point_functionality(self):
        self.pointList.setSelectionMode(
            QtWidgets.QAbstractItemView.SingleSelection
        )

        self.pointList.itemSelectionChanged.connect(self._on_list_selection)
        self.addPointButton.clicked.connect(self.add_point)
        self.updatePointButton.clicked.connect(self.update_point)
        self.reloadPointsButton.clicked.connect(self.load_points)
        self.viewYamlButton.clicked.connect(self.view_yaml)
        self.deleteAllButton.clicked.connect(self.delete_all_points)
        self.undoButton.clicked.connect(self.clear_editor)
        self.pointList.itemDoubleClicked.connect(lambda item: self._edit_list_item(item))

        self.load_points()

    def _read_points_file(self):
        if not os.path.isfile(POINTS_FILE):
            raise FileNotFoundError(f"Points file does not exist:\n{POINTS_FILE}")

        with open(POINTS_FILE, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        if not isinstance(data, dict):
            raise ValueError("points.yaml root must be a YAML mapping.")

        points = data.get("points", [])
        if points is None:
            points = []

        if not isinstance(points, list):
            raise ValueError("'points' in points.yaml must be a list.")

        self.points_file_name = data.get("points_file_name", "")
        return data, points

    def _write_points_file(self, points):
        data, _ = self._read_points_file()
        data["points"] = points

        directory = os.path.dirname(POINTS_FILE)
        os.makedirs(directory, exist_ok=True)

        temp_file = POINTS_FILE + ".tmp"

        with open(temp_file, "w", encoding="utf-8") as fh:
            yaml.safe_dump(data, fh, sort_keys=False, allow_unicode=True, default_flow_style=False)

        os.replace(temp_file, POINTS_FILE)

    def load_points(self):
        try:
            data, points = self._read_points_file()
            self.points = deepcopy(points)
            self.points_file_name = data.get("points_file_name", "")
            self._refresh_point_list()

            self.statusbar.showMessage(f"Loaded {len(self.points)} points from {POINTS_FILE}", 3000)
        except Exception as exc:
            self.points = []
            self._refresh_point_list()
            QtWidgets.QMessageBox.critical(self, "Unable to load points", f"Could not read points.yaml.\n\n{exc}")

    def _refresh_point_list(self):
        self.pointList.blockSignals(True)
        self.pointList.clear()

        for index, point in enumerate(self.points):
            name = str(point.get("name", f"point-{index + 1}"))
            item = QtWidgets.QListWidgetItem()
            row = PointRow(index, name)

            item.setSizeHint(QtCore.QSize(0, 62))
            row.executeRequested.connect(self.execute_point)
            row.editRequested.connect(self.edit_point)
            row.deleteRequested.connect(self.delete_point)

            self.pointList.addItem(item)
            self.pointList.setItemWidget(item, row)

        self.pointList.blockSignals(False)
        self.pointCountLabel.setText(f"{len(self.points)} points")

        if self.selected_point_index is not None:
            if 0 <= self.selected_point_index < len(self.points):
                self.pointList.setCurrentRow(self.selected_point_index)
            else:
                self.selected_point_index = None

    def _on_list_selection(self):
        row = self.pointList.currentRow()
        if 0 <= row < len(self.points):
            self.selected_point_index = row
            self._populate_editor(self.points[row])

    def _edit_list_item(self, item):
        row = self.pointList.row(item)
        if 0 <= row < len(self.points):
            self.edit_point(row)

    # ── editor ─────────────────────────────────────────────────────────────

    def _populate_editor(self, point):
        self.pointNameInput.setText(str(point.get("name", "")))
        self.sequenceInput.setValue(int(point.get("sequence", 1) or 1))
        self.enableTfCheck.setChecked(bool(point.get("is_tf", False)))
        self.editableCheck.setChecked(bool(point.get("is_editable", True)))

        nature = point.get("nature", "")
        self.natureInput.setPlainText("" if nature is None else str(nature))

        date_time = point.get("date_time", "")
        self.dateTimeInput.setText("" if date_time is None else str(date_time))

        self._set_position_values_from_point(point)

    # ── position values shown beside +/- buttons ──────────────────────────

    def _read_display_value(self, prefix, index):
        label = getattr(self, f"{prefix}Value{index}")
        text = label.text().strip().replace("°", "").replace("cm", "")
        try:
            return float(text)
        except ValueError:
            return 0.0

    def _write_display_value(self, prefix, index, value):
        label = getattr(self, f"{prefix}Value{index}")
        # JUST SHOW THE RAW FLOAT NO MATTER THE UNIT
        label.setText(f"{value:.2f}")

    def _set_position_values_from_point(self, point):
        self.is_loading_point = True
        
        joints = point.get("joints_values") or {}
        for i in range(1, 7):
            # NO MATH. Read raw YAML value.
            self._write_display_value("joint", i, float(joints.get(f"joint{i}", 0) or 0))

        coord = point.get("coordinate") or {}
        for i, axis in enumerate(("x", "y", "z", "r", "p", "w"), start=1):
            # NO MATH. Read raw YAML value.
            self._write_display_value("cart", i, float(coord.get(axis, 0) or 0))
            
        self.is_loading_point = False

    def _current_position_values(self):
        joints = {}
        for i in range(1, 7):
            # NO MATH. Save the exact UI float value.
            joints[f"joint{i}"] = self._read_display_value("joint", i)

        axes = ("x", "y", "z", "r", "p", "w")
        coordinate = {
            axis: self._read_display_value("cart", i)
            for i, axis in enumerate(axes, start=1)
        }
        return joints, coordinate

    def _publish_jog_command(self, prefix, axis_index, sign):
        # JUST SEND A RAW STEP SIZE, NO MATH
        if prefix == "joint":
            command_type = 0
            step_size = 1.0 
            self.ros_node.publish_command(command_type, axis_index - 1, step_size, sign)
        else:
            command_type = 1
            step_size = 1.0
            self.ros_node.publish_command(command_type, axis_index - 1, step_size, sign)

    def clear_editor(self):
        self.selected_point_index = None
        self.pointList.clearSelection()
        self.pointNameInput.clear()
        self.sequenceInput.setValue(1)
        self.enableTfCheck.setChecked(False)
        self.editableCheck.setChecked(True)
        self.natureInput.clear()
        self.dateTimeInput.clear()
        self.statusbar.showMessage("Point editor cleared", 1500)

    def _editor_values(self):
        name = self.pointNameInput.text().strip()
        nature = self.natureInput.toPlainText().strip()

        if not name:
            raise ValueError("Point name cannot be empty.")

        if any(
            str(point.get("name", "")).strip() == name
            and i != self.selected_point_index
            for i, point in enumerate(self.points)
        ):
            raise ValueError(f"A point named '{name}' already exists.")

        return {
            "name": name,
            "sequence": self.sequenceInput.value(),
            "is_tf": self.enableTfCheck.isChecked(),
            "is_editable": self.editableCheck.isChecked(),
            "nature": nature,
        }

    def add_point(self):
        try:
            values = self._editor_values()
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, "Invalid point", str(exc))
            return

        point = {
            "name": values["name"],
            "date_time": datetime.now().strftime("%d%b_%H%M").lower(),
            "sequence": values["sequence"],
            "nature": values["nature"],
            "is_tf": values["is_tf"],
            "is_calibrated": False,
            "is_editable": values["is_editable"],
        }

        point["joints_values"], point["coordinate"] = self._current_position_values()

        try:
            self.points.append(point)
            self._write_points_file(self.points)
            new_index = len(self.points) - 1
            self.selected_point_index = new_index
            self._refresh_point_list()
            self.pointList.setCurrentRow(new_index)
            self.statusbar.showMessage(f"Added point '{point['name']}'", 2500)
        except Exception as exc:
            self.load_points()
            QtWidgets.QMessageBox.critical(self, "Save failed", f"Could not save the new point.\n\n{exc}")

    def update_point(self):
        index = self.selected_point_index
        if index is None or not (0 <= index < len(self.points)):
            QtWidgets.QMessageBox.information(self, "No point selected", "Select a point to update.")
            return

        original = self.points[index]
        if original.get("is_editable", True) is False:
            QtWidgets.QMessageBox.warning(self, "Point locked", f"'{original.get('name', 'point')}' is marked as not editable.")
            return

        try:
            values = self._editor_values()
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, "Invalid point", str(exc))
            return

        updated = deepcopy(original)
        updated["name"] = values["name"]
        updated["sequence"] = values["sequence"]
        updated["nature"] = values["nature"]
        updated["is_tf"] = values["is_tf"]
        updated["is_editable"] = values["is_editable"]
        updated["joints_values"], updated["coordinate"] = self._current_position_values()

        self.points[index] = updated

        try:
            self._write_points_file(self.points)
            self._refresh_point_list()
            self.pointList.setCurrentRow(index)
            self.statusbar.showMessage(f"Updated point '{updated['name']}'", 2500)
        except Exception as exc:
            self.load_points()
            QtWidgets.QMessageBox.critical(self, "Save failed", f"Could not update the point.\n\n{exc}")

    def edit_point(self, index):
        if not (0 <= index < len(self.points)):
            return
        self.selected_point_index = index
        self.pointList.setCurrentRow(index)
        self._populate_editor(self.points[index])
        self.statusbar.showMessage(f"Editing point '{self.points[index].get('name', '')}'", 2000)

    def execute_point(self, index):
        if not (0 <= index < len(self.points)):
            return
        point = self.points[index]
        self.selected_point_index = index
        self.pointList.setCurrentRow(index)
        self._populate_editor(point)
        self.statusbar.showMessage(f"Selected point '{point.get('name', '')}' for execution", 2500)

    def delete_point(self, index):
        if not (0 <= index < len(self.points)):
            return
        point = self.points[index]
        name = str(point.get("name", f"point-{index + 1}"))

        if point.get("is_editable", True) is False:
            QtWidgets.QMessageBox.warning(self, "Point locked", f"'{name}' is marked as not editable.")
            return

        answer = QtWidgets.QMessageBox.question(
            self, "Delete point", f"Delete point '{name}'?\n\nThis will update points.yaml.",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        )

        if answer != QtWidgets.QMessageBox.Yes:
            return

        removed = self.points.pop(index)
        try:
            self._write_points_file(self.points)
            self.selected_point_index = None
            self._refresh_point_list()
            self.clear_editor()
            self.statusbar.showMessage(f"Deleted point '{removed.get('name', name)}'", 2500)
        except Exception as exc:
            self.load_points()
            QtWidgets.QMessageBox.critical(self, "Delete failed", f"Could not delete the point.\n\n{exc}")

    def delete_all_points(self):
        if not self.points:
            return

        answer = QtWidgets.QMessageBox.question(
            self, "Delete all points", "Delete all editable points from points.yaml?\n\nNon-editable/locked points will be kept.",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        )

        if answer != QtWidgets.QMessageBox.Yes:
            return

        kept = [point for point in self.points if point.get("is_editable", True) is False]
        deleted_count = len(self.points) - len(kept)
        self.points = kept

        try:
            self._write_points_file(self.points)
            self.selected_point_index = None
            self._refresh_point_list()
            self.clear_editor()
            self.statusbar.showMessage(f"Deleted {deleted_count} editable points", 2500)
        except Exception as exc:
            self.load_points()
            QtWidgets.QMessageBox.critical(self, "Delete failed", f"Could not delete points.\n\n{exc}")

    def view_yaml(self):
        if not os.path.isfile(POINTS_FILE):
            QtWidgets.QMessageBox.warning(self, "Points YAML not found", POINTS_FILE)
            return
        try:
            subprocess.Popen(["xdg-open", POINTS_FILE])
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, "Unable to open YAML", f"Could not open the file with xdg-open.\n\n{exc}")

    # ── navigation ────────────────────────────────────────────────────────
    def _setup_nav(self):
        self.nav_buttons = [self.navPointPlanning, self.navPathPlanning, self.navIoControl, self.navMainTree, self.navClientControl, self.navErrorHandling]
        group = QtWidgets.QButtonGroup(self)
        group.setExclusive(True)
        for btn in self.nav_buttons:
            group.addButton(btn)

    # ── status LEDs ───────────────────────────────────────────────────────
    def _setup_leds(self):
        self.leds = {}
        for prefix in ("op", "fault", "homing", "emergency"):
            self.leds[prefix] = [getattr(self, f"{prefix}Led{i}") for i in range(1, 7)]
        self.set_led_row("op", [True] * 6)
        self.set_led_row("homing", [True, True, True, False, False, False])

    def set_led_row(self, prefix, states, on_state="on"):
        for led, active in zip(self.leds[prefix], states):
            led.setProperty("state", on_state if active else "")
            restyle(led)

    # ── frames ────────────────────────────────────────────────────────────
    def _setup_frames(self):
        self.servoFrameSelect.addItems(FRAMES)
        self.servoFrameSelect.currentTextChanged.connect(lambda f: self.activeFrameBadge.setText(f"ACTIVE  {f}"))
        self._refresh_tf_frames()

    def _refresh_tf_frames(self):
        self.tfFrameSelect.clear()
        self.tfFrameSelect.addItems([f"{p.get('name', '')}-tf" for p in self.points])

    # ── jog ────────────────────────────────────────────────────────────────
    def _setup_jog(self):
        self.jog_buttons = {}
        for prefix, axes in (("joint", JOINT_AXES), ("cart", CART_AXES)):
            for i, axis in enumerate(axes, start=1):
                plus = getattr(self, f"{prefix}Plus{i}")
                minus = getattr(self, f"{prefix}Minus{i}")
                for btn, sign in ((plus, +1), (minus, -1)):
                    btn.pressed.connect(lambda p=prefix, a=i, s=sign: self.jog_press(p, a, s))
                    btn.released.connect(lambda p=prefix, a=i: self.jog_release(p, a))
                    btn.clicked.connect(lambda checked=False, p=prefix, a=i, s=sign: self._publish_jog_command(p, a, s))
                self.jog_buttons[(prefix, i)] = (plus, minus)

    def jog_press(self, mode, axis_index, sign):
        self.statusbar.showMessage(f"Jog press — {mode} axis {axis_index} {'+' if sign > 0 else '-'}", 500)

    def jog_release(self, mode, axis_index):
        self.statusbar.showMessage(f"Jog released — {mode} axis {axis_index}", 500)

    # ── clock ──────────────────────────────────────────────────────────────
    def _setup_clock(self):
        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self._tick()

    def _tick(self):
        now = QtCore.QTime.currentTime().toString("HH:mm:ss")
        try:
            load = os.getloadavg()
            load_text = f"{load[0]:.2f} {load[1]:.2f} {load[2]:.2f}"
        except OSError:
            load_text = "-- -- --"
        self.systemStatusLabel.setText(f"TIME : {now}\nUpTime: --\nLoad: {load_text}")

    def closeEvent(self, event):
        if self.ros_node:
            self.ros_node.destroy_node()
        super().closeEvent(event)


def main():
    rclpy.init()
    ros_node = ROSNode()
    import threading
    ros_thread = threading.Thread(target=rclpy.spin, args=(ros_node,), daemon=True)
    ros_thread.start()

    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
    app = QtWidgets.QApplication(sys.argv)

    with open(QSS_FILE, "r", encoding="utf-8") as fh:
        app.setStyleSheet(fh.read())

    window = MainWindow(ros_node)
    window.show()

    try:
        sys.exit(app.exec_())
    finally:
        rclpy.shutdown()


if __name__ == "__main__":
    main()
